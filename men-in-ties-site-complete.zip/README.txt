# Men In Ties — Favicon set

Files included:
- favicon.png (64x64)
- favicon.ico (32x32, classic format)
- favicon-32.png (32x32)
- favicon-192.png (192x192, Android/Chrome)
- favicon-180.png (180x180, Apple Touch Icon)

## Usage in index.html

Place all these files in the same folder as your index.html and add in <head>:

<link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png">
<link rel="icon" type="image/png" sizes="192x192" href="favicon-192.png">
<link rel="apple-touch-icon" href="favicon-180.png">
<link rel="icon" href="favicon.ico">

