# Men In Ties Landing + Logo

Файлы:
- index.html — лендинг (HTML)
- men-in-ties-logo.png — логотип (иконка для шапки и favicon)

Инструкция:
1. Откройте index.html и замените плейсхолдеры (YOUR_TELEGRAM_LINK и др.).
2. Залейте на Netlify/Vercel или GitHub Pages.
3. Логотип уже подключен к сайту как favicon и в шапке.
