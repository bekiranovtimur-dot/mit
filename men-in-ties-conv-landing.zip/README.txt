# Men In Ties Landing (Conversion Version)

Файлы:
- index.html — лендинг (улучшенный дизайн, конверсионный)
- men-in-ties-logo.png — логотип

Инструкция:
1. В index.html замените плейсхолдеры (YOUR_TELEGRAM_LINK и т.п.) на свои ссылки и метрики.
2. Залейте проект на Netlify / Vercel / GitHub Pages.
3. Логотип подключен автоматически.
